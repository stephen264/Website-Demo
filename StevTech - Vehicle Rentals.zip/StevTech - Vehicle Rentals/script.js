window.addEventListener('scroll', function() {
    const car = document.getElementById('car');
    const scrollPosition = window.scrollY;

    // Move the car based on scroll position
    // Adjust the multiplier to control the speed of the car
    const carMovement = scrollPosition * 0.5; // Change 0.5 to adjust speed
    car.style.transform = `translate(-50%, ${carMovement}px)`;
});